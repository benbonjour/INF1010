/************************************************************************************
*	Fichier					: Coffret.h
*	Auteur					: 
*	Description				: Definition de la classe Coffret
*	Date de creation		: 
*	Date de modification	: 
************************************************************************************/




