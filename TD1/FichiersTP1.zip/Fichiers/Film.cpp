/************************************************************************************
*	Fichier					: Film.cpp
*	Auteur					: 
*	Description				: Definition de la classe Film
*	Date de cr�ation		:
*	Date de modification	: 
************************************************************************************/
#include"Film.h"

	
