/************************************************************************************
*	Fichier					: Film.h
*	Auteur					: 
*	Description				: Definition de la classe Film
*	Date de cr�ation		: 10 Janvier 2013
*	Date de modification	: 
************************************************************************************/


#ifndef FILM_H
#define FILM_H

#include<string>
#include<iostream>

#include"Date.h"

using namespace std;

class Film
{

};

#endif // FILM_H