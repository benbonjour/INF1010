/* Fichier: main.cpp
 Noms: 
 Date de cr�ation: 10 Janvier 2013
 Date de modification: 
 Description: Programme de gestion des Coffrets de films. Permet de regrouper 
			  plusieurs Coffrets en Videotheque
*/

#include <iostream>
#include <string>
#include "Film.h"
#include "Coffret.h"
#include "Videotheque.h"

using namespace std;

int main()	

{
	
	//1) Cr�er un objet Film(unFilm) avec constructeur par d�faut ;
	
	//2) Cr�ation d'un objet Film (unAutreFilm) avec constructeur par param�tre
	//Utiliser les arguments suivants : id = 2, titre = "Tentation (New Moon)", description = "Il s'agit du deuxi�me volet de l'adaptation cin�matographique de la s�rie de romans de Stephenie Meyer" duree 120, Date: 1/1/2010
	
	
	//3) Modifier tous les attributs du Film cr��e dans 1) ;
	//utilisant les arguments suivants: id =1 titre = "Fascination (Twilight)", description = "Fascination est le premier roman de la saga twilight"  et duree = 120, Date: 12/10/2009

	

	
	//4) Allouer dynamiquement un Film utilisant le constructeur par d�faut ;
	//nom de l'objet : (unFilmDynamique)
	
	
	
	//5) Allouer dynamiquement une Film utilisant le constructeur par param�tres ;
	//Utiliser les arguments suivants : id = 4 ,titre = "Twilight, chapitre IV : R�v�lation", description = "Le mariage tant attendu a lieu"et 120, , Date: 1,1,2013
	
	
	//6) Modifier les attributs de Film cr��e dans 4) ;
	//Appel des fonctions de modification l'objet unFilmDynamique
	//Utiliser les arguments suivants :id = 3, titre = "Twilight, chapitre III : H�sitation", desciption = "La famille Cullen est de retour � Forks" et duree = 120, Date: 2/3/2012

	

	
	cout<<endl<<"***************Affichage des attributs de uneFilmDynamique***************"<<endl;
	
	//7) Afficher les informations du Film cr��e dans 4) ;
	
	
	//Allocation dynamique d'un tableau de Films de 4 elements
	
	//8) Allouer dynamiquement un tableau de 4 Films ;

	
	//9) Remplir le tableau cr�e dans 8) avec les Films cr��es pr�c�demment* ;

	
	cout<<endl<<"***************affichage du tableau de Films***************"<<endl;
	
	//10) Afficher les informations des Films du tableau ;	


	// //11) Cr�er un objet Coffret (CoffretSagaTwilight)
	//Utiliser l'id = 1 et le titre "Saga Twilight", Date:10/12/2012
	
	

	//12) Ajouter les Films du tableau dans le Coffret ;
	//Copier les Films contenues dans le tableau tableauFilm 
	//dans l'Coffret CoffretSagaTwilight
	

	 //13 creer 7 autres coffrets de votre choix avec les films de votre choix(pour simplifier les choses, deux film par cofret)
	 
	
	cout<<endl<<"***************Afficher les Films d'un Coffret***************"<<endl;
	
	//14 Afficher les film du premier coffret cr�e
	
	
	//Creation d'une Videotheque (maVideotheque)
	
	// 15) Cr�er un objet Videotheque ;
	
	//16) Ajouter tous les coffrets cr�es pr�c�demment � la Videotheque

	cout<<endl<<"*******Afficher Coffrets et Films de la Videotheque*******"<<endl;
	
	//17) Afficher les titres et les informations de tous les films de tous les Coffrets de la Videotheque ;
	
	return 0;
	
}